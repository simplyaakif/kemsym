<template>

    <footer class="card-footer">
        <slot/>
    </footer>

</template>

<script>

export default {
    name: 'CardFooter',
};

</script>
