export default [
    'top-left', 'top-right', 'top-center', 'bottom-left', 'bottom-right', 'bottom-center',
];
