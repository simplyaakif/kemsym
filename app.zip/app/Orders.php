<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Orders extends Model
{
    //
    public function productPrice()
    {
        // return $this->belongsTo('App\ProductsPrices');
    }
    
}
