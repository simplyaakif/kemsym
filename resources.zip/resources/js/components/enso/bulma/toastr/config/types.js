export default ['message', 'primary', 'info', 'success', 'warning', 'danger'];
