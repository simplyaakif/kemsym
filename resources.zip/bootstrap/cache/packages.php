<?php return array (
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'laravel-enso/helpers' => 
  array (
    'aliases' => 
    array (
      'EnsoException' => 'LaravelEnso\\Helpers\\app\\Exceptions\\EnsoException',
    ),
  ),
  'laravel-enso/vuecomponents' => 
  array (
    'providers' => 
    array (
      0 => 'LaravelEnso\\VueComponents\\AppServiceProvider',
    ),
    'aliases' => 
    array (
    ),
  ),
  'laravel-enso/vuedatatable' => 
  array (
    'providers' => 
    array (
      0 => 'LaravelEnso\\VueDatatable\\AppServiceProvider',
    ),
    'aliases' => 
    array (
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
);