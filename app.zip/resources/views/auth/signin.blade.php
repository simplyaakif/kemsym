@extends('partials.template')
    <section>
        <div class="bdcrumb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="text-center text-uppercase">
                            {{$title}}
                        </h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="page-details">
            
        </div>
    </section>
@endsection